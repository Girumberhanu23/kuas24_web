// app/api/leagues/route.ts
import { NextResponse } from "next/server";

export async function GET() {
  const res = await fetch(
    "https://v3.football.api-sports.io/leagues?season=2026&type=League",
    {
      headers: {
        "x-apisports-key": process.env.API_SPORTS_KEY!,
      },
      next: { revalidate: 86400 }, // Next.js cache: 24 hrs on the server side
    }
  );

  if (!res.ok) {
    return NextResponse.json({ error: "Failed to fetch leagues" }, { status: 502 });
  }

  const data = await res.json();

  const leagues = (data.response as any[]).map((item) => ({
    id: String(item.league.id),
    name: item.league.name,
    logo: item.league.logo,
    country: item.country.name,
  }));

  return NextResponse.json({ leagues });
}